# RAM PLAYER v19.0 — Extreme Master Edition (Build 190)

## Major Upgrades in Extreme Master Edition
- **Real PCM Audio Delay (`AudioDelayProcessor.kt`)**: Bounded circular PCM ring-buffer `BaseAudioProcessor` (`0–500ms`, ~96 KB RAM) wired into `DefaultRenderersFactory.buildAudioSink()` with fine `+25ms` steps, live active status, and `0ms` reset.
- **Generation-Safe Subtitle Delay**: `subtitleCueGeneration` token cancels all outdated delayed subtitle callbacks immediately on seek, pause, channel switch, or player recreation, with fine (`+100ms`), coarse (`+500ms`), and `0ms` reset controls.
- **WorkManager Playlist Auto-Refresh (`PlaylistRefreshWorker.kt`)**: Persistent background scheduling (`androidx.work:work-runtime-ktx:2.9.1`) with network + battery constraints, `ExistingPeriodicWorkPolicy.UPDATE` deduplication, exponential backoff retry (up to 3 attempts), cancellation, and last/next refresh timestamps.
- **Honest Audio Passthrough vs Media3 Audio Offload Separation**: Independently verifies hardware bitstream capabilities (`AudioManager.getDevices`: AC3/E-AC3/DTS/TrueHD) and separates them from Media3 `AudioOffloadPreferences`.
- **Complete Backup & AES-256-GCM Password Protection (`SmartEngineHub.kt`)**: Covers profiles, favorites, watch history, watchlists, custom groups, hidden channels, blacklists, home/sidebar layouts, remote shortcuts, delays, passthrough/offload, and auto-refresh config, with PBKDF2-HMAC-SHA256 + AES-256-GCM encryption and restore confirmation.
- **Searchable 24-Category Settings Hub, App Health Dashboard & Privacy Controls**: Live keyword search across all 24 categories, real-time App Health Dashboard, and one-tap Privacy Controls.
- **Unit Test & Gradle Readiness**: Added `testImplementation("org.json:json:20240303")` and new JUnit tests for AES-256-GCM backup encryption/decryption and `AudioDelayProcessor` bounds.
