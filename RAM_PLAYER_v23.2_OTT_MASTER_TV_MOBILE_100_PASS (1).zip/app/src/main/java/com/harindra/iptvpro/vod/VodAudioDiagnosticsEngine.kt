package com.harindra.iptvpro.vod

/**
 * RAM PLAYER v23.0 ADD-ON 3 — Advanced Audio Compatibility & Missing-Audio Diagnostics Engine.
 *
 * Investigates streams where video plays but audio is missing, distinguishing:
 * - Missing audio track in source
 * - Audio track present but unselected (triggers automatic recovery selection)
 * - Unsupported audio codec / decoder init failure
 * - Channel layout / passthrough incompatibility
 * - Stream-level audio errors
 */
enum class VodAudioHealthStatus(val label: String, val guidance: String) {
    HEALTHY("Audio Active", "Audio track is active and synchronized."),
    MISSING_AUDIO_TRACK("No Audio Track in Source", "The provider stream contains video only with no audio stream."),
    AUDIO_TRACK_UNSELECTED("Audio Track Unselected", "Audio tracks exist but none was selected — auto-selecting first valid track."),
    UNSUPPORTED_CODEC("Unsupported Audio Codec", "Audio codec unsupported by hardware; try Software Decoder or Engine Switch."),
    DECODER_INIT_FAILED("Audio Decoder Init Failed", "Audio decoder failed to initialize on this device."),
    CHANNEL_LAYOUT_INCOMPATIBLE("Multichannel / Passthrough Mismatch", "Multichannel surround may require stereo downmix on this TV."),
    STREAM_AUDIO_ERROR("Stream Audio Error", "Audio packets could not be read cleanly from the stream.")
}

data class VodAudioDiagnosticReport(
    val status: VodAudioHealthStatus,
    val totalAudioTracks: Int,
    val selectedTrackName: String,
    val audioDelayMs: Long,
    val dialoguePresetLabel: String,
    val autoRecoverTrackId: Int? = null
)

object VodAudioDiagnosticsEngine {

    fun diagnose(
        tracks: List<VodEngineTrack>,
        audioDelayMs: Long,
        dialoguePreset: VodDialoguePreset,
        lastErrorMessage: String = ""
    ): VodAudioDiagnosticReport {
        val playableTracks = tracks.filter { !it.isOffOption }
        val selected = playableTracks.firstOrNull { it.isSelected }
        val lowerErr = lastErrorMessage.lowercase()

        if (lowerErr.contains("audio") && (lowerErr.contains("codec") || lowerErr.contains("unsupported"))) {
            return VodAudioDiagnosticReport(
                status = VodAudioHealthStatus.UNSUPPORTED_CODEC,
                totalAudioTracks = playableTracks.size,
                selectedTrackName = selected?.name ?: "None",
                audioDelayMs = audioDelayMs,
                dialoguePresetLabel = dialoguePreset.label
            )
        }
        if (lowerErr.contains("audio") && lowerErr.contains("init")) {
            return VodAudioDiagnosticReport(
                status = VodAudioHealthStatus.DECODER_INIT_FAILED,
                totalAudioTracks = playableTracks.size,
                selectedTrackName = selected?.name ?: "None",
                audioDelayMs = audioDelayMs,
                dialoguePresetLabel = dialoguePreset.label
            )
        }
        if (playableTracks.isEmpty()) {
            return VodAudioDiagnosticReport(
                status = VodAudioHealthStatus.MISSING_AUDIO_TRACK,
                totalAudioTracks = 0,
                selectedTrackName = "None",
                audioDelayMs = audioDelayMs,
                dialoguePresetLabel = dialoguePreset.label
            )
        }
        if (selected == null) {
            return VodAudioDiagnosticReport(
                status = VodAudioHealthStatus.AUDIO_TRACK_UNSELECTED,
                totalAudioTracks = playableTracks.size,
                selectedTrackName = "Unselected",
                audioDelayMs = audioDelayMs,
                dialoguePresetLabel = dialoguePreset.label,
                autoRecoverTrackId = playableTracks.first().id
            )
        }

        val nameLower = selected.name.lowercase()
        val possibleSurroundMismatch = (nameLower.contains("truehd") || nameLower.contains("7.1")) && lowerErr.contains("passthrough")
        return VodAudioDiagnosticReport(
            status = if (possibleSurroundMismatch) VodAudioHealthStatus.CHANNEL_LAYOUT_INCOMPATIBLE else VodAudioHealthStatus.HEALTHY,
            totalAudioTracks = playableTracks.size,
            selectedTrackName = selected.name,
            audioDelayMs = audioDelayMs,
            dialoguePresetLabel = dialoguePreset.label
        )
    }
}
