package com.harindra.iptvpro

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * RAM PLAYER v23.2 OTT-ENGINE MASTER EDITION — Dedicated OTT Navigator-Grade LibVLC Live TV Engine.
 *
 * Uses the already-bundled official VideoLAN LibVLC 3.6.5 (FFmpeg/avcodec) native engine for Live TV
 * whenever Media3 ExoPlayer encounters:
 * - Dolby Digital AC-3 5.1 (6ch), E-AC-3, DTS, TrueHD, or MP2 audio without platform decoders
 * - Interlaced 1080i50 (25fps) H.264/MPEG-2 Indian DTH restreams (Sony Max HD, Zee Cinema HD, Star Gold HD)
 * - Silent MediaCodec black screen (audio playing or STATE_READY with 0 rendered video frames)
 * - Non-standard Xtream MPEG-TS / HLS containers
 *
 * Completely independent from VodPlayerActivity's LibVlcVodPlayerEngine and lazily initialized
 * so normal Media3 channels consume 0 extra RAM.
 */
class LiveTvLibVlcEngine(
    private val context: Context
) {

    interface Callbacks {
        fun onOpening()
        fun onBuffering(percent: Float)
        fun onPlaying()
        fun onFirstVideoFrame(width: Int, height: Int)
        fun onTracksUpdated(audioSummary: String)
        fun onError(reason: String)
        fun onEnded()
    }

    data class VlcAudioTrackInfo(
        val id: Int,
        val name: String,
        val isSelected: Boolean
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private var libVlc: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private var attachedLayout: VLCVideoLayout? = null
    private var callbacks: Callbacks? = null

    private var activeForceSoftware: Boolean = false
    private var activeCachingMs: Int = 1800
    private var activeUserAgent: String = ""
    private var currentUrl: String = ""
    private var reportedFirstFrame: Boolean = false
    private var currentVolumePct: Int = 100
    private var currentAudioDelayMs: Long = 0L

    fun setCallbacks(callbacks: Callbacks?) {
        this.callbacks = callbacks
    }

    fun attachVideoLayout(layout: VLCVideoLayout) {
        attachedLayout = layout
        mediaPlayer?.let { mp ->
            runCatching { mp.detachViews() }
            runCatching { mp.attachViews(layout, null, false, false) }
        }
    }

    fun detachVideoLayout() {
        runCatching { mediaPlayer?.detachViews() }
        attachedLayout = null
    }

    private fun ensureInitialized(forceSoftware: Boolean, cachingMs: Int, userAgent: String) {
        if (libVlc != null &&
            mediaPlayer != null &&
            activeForceSoftware == forceSoftware &&
            activeCachingMs == cachingMs &&
            activeUserAgent == userAgent
        ) {
            return
        }
        val prevLayout = attachedLayout
        releaseInternal(keepLayoutRef = true)

        activeForceSoftware = forceSoftware
        activeCachingMs = cachingMs.coerceIn(800, 10_000)
        activeUserAgent = userAgent

        // Exact OTT Navigator-proven LibVLC options for Indian Xtream MPEG-TS / HLS / AC3 / 1080i50 streams
        val options = ArrayList<String>().apply {
            add("--network-caching=$activeCachingMs")
            add("--live-caching=$activeCachingMs")
            add("--clock-jitter=0")
            add("--clock-synchro=0")
            add("--drop-late-frames")
            add("--skip-frames")
            add("--http-reconnect")
            if (userAgent.isNotBlank()) {
                add("--http-user-agent=$userAgent")
            }
            add("--aout=android_audiotrack")
            add("--avcodec-fast")
            add("--deinterlace=-1")
            add("--deinterlace-mode=yadif")
            add("--no-stats")
            if (forceSoftware) {
                add("--codec=avcodec,all")
                add("--avcodec-hw=none")
            }
        }

        val vlc = LibVLC(context.applicationContext, options)
        val mp = MediaPlayer(vlc)
        mp.setEventListener(eventListener)
        libVlc = vlc
        mediaPlayer = mp

        if (prevLayout != null) {
            attachVideoLayout(prevLayout)
        }
    }

    fun playLiveStream(
        streamUrl: String,
        forceSoftware: Boolean,
        headers: Map<String, String> = emptyMap(),
        networkCachingMs: Int = 1800
    ): Boolean {
        val cleanUrl = streamUrl.trim()
        if (cleanUrl.isEmpty()) return false

        val ua = headers.entries.firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value
            ?.takeIf { it.isNotBlank() }
            ?: if (forceSoftware) "VLC/3.0.21 LibVLC/3.0.21" else NetworkClient.resolveEffectiveUserAgent(null)

        ensureInitialized(forceSoftware, networkCachingMs, ua)
        val vlc = libVlc ?: return false
        val mp = mediaPlayer ?: return false

        currentUrl = cleanUrl
        reportedFirstFrame = false

        runCatching { mp.stop() }

        val media = Media(vlc, Uri.parse(cleanUrl))
        if (forceSoftware) {
            media.setHWDecoderEnabled(false, false)
            media.addOption(":no-hw-dec")
        } else {
            media.setHWDecoderEnabled(true, false)
        }
        media.addOption(":codec=all")
        media.addOption(":network-caching=$activeCachingMs")
        media.addOption(":live-caching=$activeCachingMs")
        media.addOption(":http-reconnect")
        if (ua.isNotBlank()) {
            media.addOption(":http-user-agent=$ua")
        }
        val refHeader = headers.entries.firstOrNull { it.key.equals("Referer", ignoreCase = true) }?.value
        if (!refHeader.isNullOrBlank()) {
            media.addOption(":http-referrer=$refHeader")
        }

        mp.setMedia(media)
        media.release()
        runCatching { mp.setVolume(currentVolumePct) }
        mp.play()
        if (currentAudioDelayMs != 0L) {
            runCatching { mp.setAudioDelay(currentAudioDelayMs * 1000L) }
        }
        return true
    }

    fun isPlaying(): Boolean = runCatching { mediaPlayer?.isPlaying == true }.getOrDefault(false)

    fun isActive(): Boolean = currentUrl.isNotEmpty() && mediaPlayer != null

    fun isSoftwareMode(): Boolean = activeForceSoftware

    fun pause() {
        runCatching { mediaPlayer?.pause() }
    }

    fun resume() {
        runCatching { mediaPlayer?.play() }
    }

    fun stop() {
        currentUrl = ""
        reportedFirstFrame = false
        runCatching { mediaPlayer?.stop() }
    }

    fun setAudioDelayMs(delayMs: Long) {
        currentAudioDelayMs = delayMs.coerceIn(-2000L, 2000L)
        runCatching { mediaPlayer?.setAudioDelay(currentAudioDelayMs * 1000L) }
    }

    fun setVolumePercent(percent: Int) {
        currentVolumePct = percent.coerceIn(0, 150)
        runCatching { mediaPlayer?.setVolume(currentVolumePct) }
    }

    fun setAspectRatioByResizeIndex(resizeIndex: Int) {
        val mp = mediaPlayer ?: return
        val scaleType = when (resizeIndex % 5) {
            0 -> MediaPlayer.ScaleType.SURFACE_BEST_FIT
            1 -> MediaPlayer.ScaleType.SURFACE_FILL
            2 -> MediaPlayer.ScaleType.SURFACE_FIT_SCREEN
            3 -> MediaPlayer.ScaleType.SURFACE_16_9
            else -> MediaPlayer.ScaleType.SURFACE_4_3
        }
        runCatching { mp.setVideoScale(scaleType) }
    }

    fun getAudioTracks(): List<VlcAudioTrackInfo> {
        val mp = mediaPlayer ?: return emptyList()
        val currentId = runCatching { mp.getAudioTrack() }.getOrDefault(-1)
        val raw = runCatching { mp.getAudioTracks() }.getOrNull() ?: return emptyList()
        return raw.mapNotNull { td ->
            if (td == null || td.id < 0) null
            else VlcAudioTrackInfo(
                id = td.id,
                name = td.name.orEmpty().ifBlank { "Audio Track #${td.id}" },
                isSelected = td.id == currentId
            )
        }
    }

    fun selectAudioTrack(trackId: Int): Boolean {
        val mp = mediaPlayer ?: return false
        return runCatching { mp.setAudioTrack(trackId) }.getOrDefault(false)
    }

    private fun buildAudioSummary(): String {
        val tracks = getAudioTracks()
        val selected = tracks.firstOrNull { it.isSelected } ?: tracks.firstOrNull()
        return selected?.name?.take(18) ?: "FFmpeg Audio"
    }

    private val eventListener = MediaPlayer.EventListener { event ->
        when (event.type) {
            MediaPlayer.Event.Opening -> {
                mainHandler.post { callbacks?.onOpening() }
            }
            MediaPlayer.Event.Buffering -> {
                val pct = event.buffering
                mainHandler.post { callbacks?.onBuffering(pct) }
            }
            MediaPlayer.Event.Playing -> {
                if (currentAudioDelayMs != 0L) {
                    runCatching { mediaPlayer?.setAudioDelay(currentAudioDelayMs * 1000L) }
                }
                mainHandler.post {
                    callbacks?.onPlaying()
                    callbacks?.onTracksUpdated(buildAudioSummary())
                }
            }
            MediaPlayer.Event.Vout -> {
                if (event.voutCount > 0 && !reportedFirstFrame) {
                    reportedFirstFrame = true
                    val vt = runCatching { mediaPlayer?.getCurrentVideoTrack() }.getOrNull()
                    val w = vt?.width ?: 0
                    val h = vt?.height ?: 0
                    mainHandler.post {
                        callbacks?.onFirstVideoFrame(w, h)
                        callbacks?.onTracksUpdated(buildAudioSummary())
                    }
                }
            }
            MediaPlayer.Event.ESAdded,
            MediaPlayer.Event.ESSelected -> {
                mainHandler.post { callbacks?.onTracksUpdated(buildAudioSummary()) }
            }
            MediaPlayer.Event.EndReached -> {
                mainHandler.post { callbacks?.onEnded() }
            }
            MediaPlayer.Event.EncounteredError -> {
                mainHandler.post { callbacks?.onError("LibVLC live playback error") }
            }
        }
    }

    private fun releaseInternal(keepLayoutRef: Boolean) {
        mainHandler.removeCallbacksAndMessages(null)
        currentUrl = ""
        reportedFirstFrame = false
        val mp = mediaPlayer
        val vlc = libVlc
        mediaPlayer = null
        libVlc = null
        runCatching { mp?.setEventListener(null) }
        runCatching { mp?.stop() }
        runCatching { mp?.detachViews() }
        runCatching { mp?.release() }
        runCatching { vlc?.release() }
        if (!keepLayoutRef) {
            attachedLayout = null
        }
    }

    fun release() {
        releaseInternal(keepLayoutRef = false)
    }
}
