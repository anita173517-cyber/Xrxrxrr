package com.harindra.iptvpro

import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Dedicated AndroidX Media3 MediaSessionService for RAM PLAYER v21.0.
 *
 * Maintains a single authoritative MediaSession attached to the active ExoPlayer instance
 * without creating duplicate players. Safely isolates Live TV player ownership from the
 * dedicated VOD player so closing VOD never releases or corrupts Live TV's MediaSession.
 */
@OptIn(UnstableApi::class)
class RamPlayerPlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        activeServiceInstance = this
        val initialPlayer = activeVodPlayer ?: pendingPlayer
        initialPlayer?.let { attachPlayerInternal(it) }
    }

    private fun attachPlayerInternal(player: Player) {
        val current = mediaSession
        if (current != null && current.player === player) return
        current?.release()
        mediaSession = MediaSession.Builder(this, player)
            .setId(SESSION_ID)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.playbackState == Player.STATE_ENDED) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        mediaSession?.release()
        mediaSession = null
        if (activeServiceInstance === this) {
            activeServiceInstance = null
        }
        super.onDestroy()
    }

    companion object {
        const val SESSION_ID = "ram_player_v20_authoritative_session"

        @Volatile
        private var activeServiceInstance: RamPlayerPlaybackService? = null

        @Volatile
        private var pendingPlayer: Player? = null

        @Volatile
        private var activeVodPlayer: Player? = null

        fun registerAuthoritativePlayer(player: Player) {
            pendingPlayer = player
            if (activeVodPlayer == null) {
                activeServiceInstance?.attachPlayerInternal(player)
            }
        }

        fun unregisterAuthoritativePlayer(player: Player?) {
            if (player == null || pendingPlayer === player) {
                pendingPlayer = null
            }
            if (activeVodPlayer == null) {
                activeServiceInstance?.let { svc ->
                    if (player == null || svc.mediaSession?.player === player) {
                        svc.mediaSession?.release()
                        svc.mediaSession = null
                    }
                }
            }
        }

        fun registerVodPlayer(player: Player) {
            activeVodPlayer = player
            activeServiceInstance?.attachPlayerInternal(player)
        }

        fun unregisterVodPlayer(player: Player?) {
            if (player == null || activeVodPlayer === player) {
                activeVodPlayer = null
            }
            val liveFallback = pendingPlayer
            activeServiceInstance?.let { svc ->
                if (liveFallback != null) {
                    svc.attachPlayerInternal(liveFallback)
                } else if (player == null || svc.mediaSession?.player === player) {
                    svc.mediaSession?.release()
                    svc.mediaSession = null
                }
            }
        }

        fun hasActiveSession(): Boolean = activeServiceInstance?.mediaSession != null
    }
}
