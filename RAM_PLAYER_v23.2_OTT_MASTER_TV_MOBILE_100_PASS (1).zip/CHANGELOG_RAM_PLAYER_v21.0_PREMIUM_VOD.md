# RAM PLAYER v21.0 → PREMIUM DEDICATED VOD PLAYER EDITION

## 1. Upgrade Overview
Built directly on top of the original `RAM_PLAYER_v21.0_FINAL_35_OF_35_PASS (2).zip` source tree with **100% Live TV preservation** and a **completely independent, dedicated OTT VOD Player + redesigned Movies & Series TV interface**.

## 2. Live TV Regression Protection (Zero Modification Guarantee)
All 14 core/Live TV Kotlin files (`AudioDelayProcessor.kt`, `BootReceiver.kt`, `ChannelCacheStore.kt`, `EpgCacheStore.kt`, `M3uParser.kt`, `Models.kt`, `NetworkClient.kt`, `PlaylistRefreshWorker.kt`, `ProfileStore.kt`, `SmartEngineHub.kt`, `StreamPreFetcher.kt`, `StreamXApp.kt`, `XmltvParser.kt`, `XtreamRepository.kt`) remain **byte-for-byte identical** to the original ZIP.
- Live TV `exoPlayer`, `media3PlayerView`, `zappingOsdContainer`, `leftChannelDrawer`, `topControlBar`, `dthBootOverlay`, `okHoldDeleteOverlay`, fast zapping, channel prefetching, No Reconnect Fix, M3U/Xtream Live TV, EPG, favorites, search, profiles, and settings remain completely untouched.
- `RamPlayerPlaybackService.kt` adds isolated `registerVodPlayer` / `unregisterVodPlayer` ownership guards so closing VOD never releases or corrupts Live TV's `MediaSession`.

## 3. Dedicated VOD Player Architecture (`com.harindra.iptvpro.vod`)
- **`VodPlayerActivity.kt`** + **`activity_vod_player.xml`**: Dedicated full-screen 4D Glassmorphism cinema player with its own independent `@+id/vodPlayerView` (never uses Live TV `media3PlayerView` or Live TV OSD).
- **`VodPlaybackManager.kt`**: Independent Media3 `ExoPlayer`, `DefaultTrackSelector`, dedicated `AudioDelayProcessor`, `OkHttpDataSource.Factory(NetworkClient.streamClient)`, and low-RAM adaptive `DefaultLoadControl` (512MB/1GB/2GB/4GB+ safe).
- **`VodSeekController.kt`**: Configurable seek intervals (5s, 10s default, 15s, 20s, 30s, 60s), long-press continuous accelerated scrubbing (1x→4x), floating seek preview pill, duration clamping, and unknown-duration/live-like VOD handling.
- **`VodTrackSelectionManager.kt`**: Real Media3 `Tracks` inspection for Video Quality (Auto + genuine available resolutions 360p–2160p 4K, honest fixed single-stream notice for progressive files), Audio Tracks (language, codec, Stereo/5.1/7.1 layout, audio sync delay), and Subtitles (Off, embedded & external sidecar tracks).
- **`VodSubtitleController.kt`**: TV-readable `CaptionStyleCompat` presets (Cinema Glass, TV Yellow, White Outline, Neon Cyan), 4 font sizes, and subtitle sync offset.
- **`VodAutoNextController.kt`**: Cross-season Previous/Next Episode navigation, single-trigger Auto-Next countdown card (5s–20s configurable) with Play Now and Cancel.
- **`VodPlaybackErrorHandler.kt`**: VOD-specific HTTP 401/403, 404/410, 429, 5xx, network, manifest, decoder, codec, and audio error handling with strictly bounded retries (max 3 transient, 0 fatal — never infinite loops, never touches Live TV).
- **`VodProgressStore.kt`**: Movie vs. Series Episode progress isolation, resume/start-over/rewatch, 92% completion threshold, backward-compatible with `ProfileStore`.
- **`VodPreferencesStore.kt`**: Isolated SharedPreferences (`ram_player_vod_prefs_v21`) storing all 14 VOD settings without touching Live TV settings.
- **`VodRemoteControlController.kt`**: Android TV D-pad & media-key router (auto-hide awareness, zero focus traps, Back hierarchy, zero Live TV interference).
- **`VodPlayerLauncher.kt`**: Clean Intent payload codec connecting Movies & Series Details directly to `VodPlayerActivity`.

## 4. Movies & Series Cinema OTT UI Redesign
- Redesigned `vodPosterGridPanel` in `activity_player.xml` with obsidian 4D glass canvas (`bg_vod_ott_canvas.xml`), glass top bar, Smart Filter button, frosted left category rail (`bg_vod_sidebar_item_ott.xml`), **live D-pad Focus Spotlight Hero Banner** (`vodSpotlightBanner`), and tall 2:3 cinema poster cards with gradient scrim and glowing neon focus border (`bg_vod_poster_card_ott.xml`).
- Widened Movie & Series Details overlays (`760dp`/`780dp`) with expanded season support and direct launch into `VodPlayerActivity`.

## 5. Automated Tests & Verification
- Added `VodPlayerArchitectureTest.kt` (7 test suites covering seek, continuous scrub, progress/completion isolation, auto-next single-trigger, error handling/retry cap, isolated preferences, TV remote routing, JSON & track formatting).
- Added `LiveTvVodIsolationRegressionTest.kt` (3 regression tests verifying Live TV state survival across VOD entry/exit/errors, isolated VOD prefs file, and unchanged Xtream Live URL building).
- `python3 scripts/verify_project.py`: **PASS** (70 drawables, 122 view IDs, all XMLs, all `R.*` references, all `nextFocus*` chains, and all dedicated VOD components verified).
- **Environment Limitation**: Local sandbox has OpenJDK 17 and Python 3 but no Gradle/Android SDK/internet, so full `gradle testDebugUnitTest assembleDebug assembleRelease` must be executed via GitHub Actions (`.github/workflows/build_apk.yml`, Gradle 8.13, SDK 36, JDK 17) or Android Studio.
